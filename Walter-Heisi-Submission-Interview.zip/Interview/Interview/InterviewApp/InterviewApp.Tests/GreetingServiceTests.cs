﻿using System;
using System.Collections.Generic;
using Xunit;
using Moq;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using InterviewApp.Services;
using InterviewApp.Models;
using InterviewApp.Interfaces;

namespace InterviewApp.Tests.Services
{
    public class GreetingServiceTests
    {
        private GreetingService CreateService(
            GreetingOptions options,
            string timeGreeting = "Good morning")
        {
            var optionsMock = Mock.Of<IOptions<GreetingOptions>>(o => o.Value == options);

            var loggerMock = new Mock<ILogger<GreetingService>>();

            var timeServiceMock = new Mock<ITimeGreetingService>();
            timeServiceMock.Setup(t => t.GetTimeGreeting()).Returns(timeGreeting);

            return new GreetingService(
                optionsMock,
                loggerMock.Object,
                timeServiceMock.Object
            );
        }

        [Fact]
        public void Run_WithValidLanguage_DisplaysCorrectGreeting()
        {
            // Arrange
            var options = new GreetingOptions
            {
                Language = "English",
                Message = "Welcome to the interview app!"
            };

            var service = CreateService(options, "Good morning");

            using var sw = new System.IO.StringWriter();
            Console.SetOut(sw);

            // Act
            service.Run();

            // Assert
            var output = sw.ToString().Trim();
            Assert.Equal("Good morning! Welcome to the interview app!", output);
        }

        [Fact]
        public void Run_WithUnsupportedLanguage_FallsBackToEnglish()
        {
            // Arrange
            var options = new GreetingOptions
            {
                Language = "French",
                Message = "Welcome to the interview app!"
            };

            var service = CreateService(options, "Good afternoon");

            using var sw = new System.IO.StringWriter();
            Console.SetOut(sw);

            // Act
            service.Run();

            // Assert
            var output = sw.ToString().Trim();
            Assert.Equal("Good afternoon! Welcome to the interview app!", output);
        }

        [Fact]
        public void Run_WithNullLanguage_FallsBackToEnglish()
        {
            // Arrange
            var options = new GreetingOptions
            {
                Language = null!,
                Message = "Welcome to the interview app!"
            };

            var service = CreateService(options, "Good evening");

            using var sw = new System.IO.StringWriter();
            Console.SetOut(sw);

            // Act
            service.Run();

            // Assert
            var output = sw.ToString().Trim();
            Assert.Equal("Good evening! Welcome to the interview app!", output);
        }

        [Fact]
        public void Run_CombinesTimeGreetingWithLanguageGreeting()
        {
            // Arrange
            var options = new GreetingOptions
            {
                Language = "Zulu",
                Message = "Welcome to the interview app!"
            };

            var service = CreateService(options, "Good night");

            using var sw = new System.IO.StringWriter();
            Console.SetOut(sw);

            // Act
            service.Run();

            // Assert
            var output = sw.ToString().Trim();
            Assert.Equal("Good night! Siyakwamukela kuhlelo lokuhlolwa!", output);
        }

        [Fact]
        public void Run_WhenTimeServiceThrows_ErrorIsHandledGracefully()
        {
            // Arrange
            var options = new GreetingOptions
            {
                Language = "English",
                Message = "Welcome to the interview app!"
            };

            var optionsMock = Mock.Of<IOptions<GreetingOptions>>(o => o.Value == options);
            var loggerMock = new Mock<ILogger<GreetingService>>();

            var timeServiceMock = new Mock<ITimeGreetingService>();
            timeServiceMock
                .Setup(t => t.GetTimeGreeting())
                .Throws(new Exception("Time service failure"));

            var service = new GreetingService(
                optionsMock,
                loggerMock.Object,
                timeServiceMock.Object
            );

            using var sw = new System.IO.StringWriter();
            Console.SetOut(sw);

            // Act
            service.Run();

            // Assert
            var output = sw.ToString().Trim();
            Assert.Equal("Welcome to the interview app!", output);
        }
    }
}

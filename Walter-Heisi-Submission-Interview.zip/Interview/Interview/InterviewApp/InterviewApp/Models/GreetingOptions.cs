﻿using System.ComponentModel.DataAnnotations;

namespace InterviewApp.Models
{
    public class GreetingOptions
    {
        [Required]
        public string Message { get; set; } = string.Empty;

        [Required]
        public string Language { get; set; } = string.Empty;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterviewApp.Interfaces
{
    public interface ITimeGreetingService
    {
        string GetTimeGreeting();
    }
}

﻿namespace InterviewApp.Interfaces;

public interface IGreetingService
{
    void Run();
}
﻿using InterviewApp.Interfaces;
using InterviewApp.MediatR.Queries;
using InterviewApp.Services;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

public class GetTimeGreetingHandler : IRequestHandler<GetTimeGreetingQuery, string>
{
    private readonly ITimeGreetingService _timeService;

    public GetTimeGreetingHandler(ITimeGreetingService timeService)
    {
        _timeService = timeService;
    }

    public Task<string> Handle(GetTimeGreetingQuery request, CancellationToken cancellationToken)
    {
        var timeGreeting = _timeService.GetTimeGreeting();
        return Task.FromResult(timeGreeting);
    }
}


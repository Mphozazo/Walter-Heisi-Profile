﻿using MediatR;

namespace InterviewApp.MediatR.Commands
{
    public record GreetUserCommand(string Language) : IRequest<string>;
}

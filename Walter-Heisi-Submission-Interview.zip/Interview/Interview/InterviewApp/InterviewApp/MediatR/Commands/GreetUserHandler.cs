﻿using InterviewApp.MediatR.Commands;
using InterviewApp.MediatR.Queries;
using InterviewApp.Models;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

public class GreetUserHandler : IRequestHandler<GreetUserCommand, string>
{
    private readonly GreetingOptions _options;
    private readonly ILogger<GreetUserHandler> _logger;
    private readonly IMediator _mediator;

    private readonly Dictionary<string, string> _greetings = new(StringComparer.OrdinalIgnoreCase)
    {
        { "English", "Welcome to the interview app!" },
        { "Afrikaans", "Welkom by die onderhoud-toep!" },
        { "Zulu", "Siyakwamukela kuhlelo lokuhlolwa!" }
    };

    public GreetUserHandler(
        IOptions<GreetingOptions> options,
        ILogger<GreetUserHandler> logger,
        IMediator mediator)
    {
        _options = options.Value;
        _logger = logger;
        _mediator = mediator;
    }

    public async Task<string> Handle(GreetUserCommand request, CancellationToken cancellationToken)
    {
        try
        {
            var language = request.Language ?? _options.Language ?? "English";

            // Get the time-based greeting via MediatR
            var timeGreeting = await _mediator.Send(new GetTimeGreetingQuery(), cancellationToken);

            string baseGreeting;
            if (!_greetings.TryGetValue(language, out baseGreeting))
            {
                _logger.LogError(
                    "Unsupported language '{Language}' configured. Falling back to English.",
                    language);

                baseGreeting = _greetings["English"];
            }

            var finalMessage = $"{timeGreeting}! {baseGreeting}";
            _logger.LogInformation("Final greeting: {Message}", finalMessage);

            return finalMessage;
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Error generating greeting");

            // Graceful fallback
            return "Welcome to the interview app!";
        }
    }
}

﻿using InterviewApp.Interfaces;
using InterviewApp.MediatR.Commands;
using InterviewApp.Models;
using InterviewApp.Services;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        using IHost host = Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration((context, config) =>
            {
                config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            })
            .ConfigureServices((context, services) =>
            {
                // Bind GreetingOptions with validation
                services.AddOptions<GreetingOptions>()
                    .Bind(context.Configuration.GetSection("Greeting"))
                    // validate that Message and Language are not null or whitespace
                    .Validate(opt => !string.IsNullOrWhiteSpace(opt.Message), "Greeting:Message is required")
                    .Validate(opt => !string.IsNullOrWhiteSpace(opt.Language), "Greeting:Language is required")
                    .ValidateOnStart();

                // Register services
                services.AddTransient<ITimeGreetingService, TimeGreetingService>();
                services.AddTransient<IGreetingService, GreetingService>();

                // Register MediatR
                services.AddMediatR(cfg =>
                    cfg.RegisterServicesFromAssembly(typeof(Program).Assembly)
                );
            })
            .ConfigureLogging(logging =>
            {
                logging.ClearProviders();
                logging.AddConsole();
                logging.SetMinimumLevel(LogLevel.Information);
            })
            .Build();

        var logger = host.Services.GetRequiredService<ILogger<Program>>();

        try
        {
            using var scope = host.Services.CreateScope();
            var mediator = scope.ServiceProvider.GetRequiredService<IMediator>();

            // Send a greeting command through MediatR
            var options = scope.ServiceProvider.GetRequiredService<IOptions<GreetingOptions>>().Value;
            var language = options.Language ?? "English"; // fallback just in case

            var greetingMessage = await mediator.Send(new GreetUserCommand(language));

            Console.WriteLine(greetingMessage);

            await host.RunAsync();
        }
        catch (OptionsValidationException ex)
        {
            logger.LogCritical("Application startup failed due to invalid configuration");

            foreach (var failure in ex.Failures)
            {
                logger.LogCritical("Config validation error: {Error}", failure);
            }

            logger.LogCritical("Application shutting down gracefully");
            Environment.ExitCode = 1;
        }
        catch (Exception ex)
        {
            logger.LogCritical(ex, "Unexpected fatal error occurred. Shutting down gracefully.");
            Environment.ExitCode = 1;
        }
    }
}


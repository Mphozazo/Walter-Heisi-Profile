﻿using InterviewApp.Interfaces;
using InterviewApp.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;

namespace InterviewApp.Services
{
    public class GreetingService : IGreetingService
    {
        private readonly GreetingOptions _options;
        private readonly ILogger<GreetingService> _logger;
        private readonly ITimeGreetingService _timeGreetingService;

        private readonly Dictionary<string, string> _greetings = new(StringComparer.OrdinalIgnoreCase)
        {
            { "English", "Welcome to the interview app!" },
            { "Afrikaans", "Welkom by die onderhoud-toep!" },
            { "Zulu", "Siyakwamukela kuhlelo lokuhlolwa!" }
        };

        public GreetingService(
            IOptions<GreetingOptions> options,
            ILogger<GreetingService> logger,
            ITimeGreetingService timeGreetingService)
        {
            _options = options.Value;
            _logger = logger;
            _timeGreetingService = timeGreetingService;
        }

        public void Run()
        {
            _logger.LogInformation("GreetingService started");

            try
            {
                var timeGreeting = _timeGreetingService.GetTimeGreeting();
                var language = _options.Language;

                if (string.IsNullOrWhiteSpace(language))
                {
                    _logger.LogError("Configured language is null or empty. Falling back to English.");
                    language = "English";
                }

                if (!_greetings.TryGetValue(language, out var baseGreeting))
                {
                    // Unsupported language
                    _logger.LogError(
                        "Unsupported language '{Language}' configured. Falling back to English.",
                        language);

                    baseGreeting = _greetings["English"];
                }

                var finalMessage = $"{timeGreeting}! {baseGreeting}";

                Console.WriteLine(finalMessage);

                _logger.LogInformation(
                    "Greeting successfully displayed: {Message}",
                    finalMessage);
            }
            catch (Exception ex)
            {
                // Error logging
                _logger.LogCritical(ex, "Fatal error occurred in GreetingService");

                // Graceful fallback output
                var safeMessage = "Welcome to the interview app!";
                Console.WriteLine(safeMessage);

                _logger.LogCritical(
                    "Fallback greeting displayed due to error: {Message}",
                    safeMessage);
            }
        }
    }
}

